package com.kh.chap01_file.run;

import com.kh.chap01_file.controller.FileBasicTest;

public class Run {

	public static void main(String[] args) {
		FileBasicTest fb = new FileBasicTest();
		fb.method1();

	}

}
