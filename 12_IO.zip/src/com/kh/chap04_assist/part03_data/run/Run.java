package com.kh.chap04_assist.part03_data.run;

import com.kh.chap04_assist.part03_data.model.dao.DataTest;

public class Run {

	public static void main(String[] args) {
		DataTest dt = new DataTest();
//		dt.fileSave();
//		dt.fileOpen();
		
		dt.fileSave2();
		dt.fileOpen2();

	}

}
