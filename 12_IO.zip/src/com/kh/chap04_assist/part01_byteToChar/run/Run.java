package com.kh.chap04_assist.part01_byteToChar.run;

import com.kh.chap04_assist.part01_byteToChar.controller.byteToCharTest;

public class Run {
	
	public static void main(String[] args) {
		
		byteToCharTest bt = new byteToCharTest();
//		bt.input();
		bt.output();
	}

}
